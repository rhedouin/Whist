% createOneWMModel example

